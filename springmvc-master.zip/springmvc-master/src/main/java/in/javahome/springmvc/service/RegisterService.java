package in.javahome.springmvc.service;

import in.javahome.springmvc.model.Register;

public interface RegisterService {
  public void register(Register reg);
}
